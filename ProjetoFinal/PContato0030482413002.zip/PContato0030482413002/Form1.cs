﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;


namespace PContato0030482413002
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conexao; //variável pública e constante que utiliza uma conexão com o sql server

        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new SqlConnection("Data Source = Gostosa\\SQLEXPRESS; Initial Catalog = LP2; Integrated Security = True; Pooling = False");
                conexao.Open();
            }

            catch(Exception ex)
            {
                MessageBox.Show("Erro ao abrir banco de dados" + ex.Message);
            }
        }

        private void cadastroContatosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmContato"];

            if (fc != null)
                fc.Close();

            frmContato FRMC = new frmContato();
            FRMC.MdiParent = this;
            FRMC.WindowState = FormWindowState.Maximized;
            FRMC.Show();
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fc1 = Application.OpenForms["abtbxSobreNos"];

            if (fc1 != null)
                fc1.Close();

            abtbxSobreNos FRMC = new abtbxSobreNos();
            FRMC.MdiParent = this;
            FRMC.WindowState = FormWindowState.Maximized;
            FRMC.Show();
        }
    }
}
