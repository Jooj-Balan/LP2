﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void colarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Opção menu Colar");
        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Opção menu copiar");
        }

        private void exercicio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio2>().Count() > 0) 
            {
                MessageBox.Show("Form já Existe");
                Application.OpenForms["frmExercicio2"].BringToFront();
                //ou
                //Application.OpenForms["frmExercicio2"].Activate();
            }
            else
            {
                frmExercicio2 obj2 = new frmExercicio2();
                obj2.MdiParent = this;//form1
                obj2.WindowState = FormWindowState.Maximized;
                obj2.Show();
            }
        }

        private void exercicio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio3>().Count() > 0)
            {
                MessageBox.Show("Form já Existe");
                Application.OpenForms["frmExercicio3"].BringToFront();
                //ou
                //Application.OpenForms["frmExercicio3"].Activate();
            }
            else
            {
                frmExercicio3 obj3 = new frmExercicio3();
                obj3.MdiParent = this;//form1
                obj3.WindowState = FormWindowState.Maximized;
                obj3.Show();
            }
        }

        private void exercicio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {
                MessageBox.Show("Form já Existe");
                Application.OpenForms["frmExercicio4"].BringToFront();
                //ou
                //Application.OpenForms["frmExercicio4"].Activate();
            }
            else
            {
                frmExercicio4 obj4 = new frmExercicio4();
                obj4.MdiParent = this;//form1
                obj4.WindowState = FormWindowState.Maximized;
                obj4.Show();
            }
        }

        private void exercicio5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                MessageBox.Show("Form já Existe");
                Application.OpenForms["frmExercicio5"].BringToFront();
                //ou
                //Application.OpenForms["frmExercicio5"].Activate();
            }
            else
            {
                frmExercicio5 obj5 = new frmExercicio5();
                obj5.MdiParent = this;//form1
                obj5.WindowState = FormWindowState.Maximized;
                obj5.Show();
            }
        }
    }
}
