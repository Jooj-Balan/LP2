﻿namespace PTesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnCont = new System.Windows.Forms.Button();
            this.btnPrimeiroEspaço = new System.Windows.Forms.Button();
            this.btnContLetras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(242, 63);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(345, 120);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // btnCont
            // 
            this.btnCont.Location = new System.Drawing.Point(199, 263);
            this.btnCont.Name = "btnCont";
            this.btnCont.Size = new System.Drawing.Size(88, 41);
            this.btnCont.TabIndex = 1;
            this.btnCont.Text = "Contar Numeros";
            this.btnCont.UseVisualStyleBackColor = true;
            this.btnCont.Click += new System.EventHandler(this.btnCont_Click);
            // 
            // btnPrimeiroEspaço
            // 
            this.btnPrimeiroEspaço.Location = new System.Drawing.Point(386, 263);
            this.btnPrimeiroEspaço.Name = "btnPrimeiroEspaço";
            this.btnPrimeiroEspaço.Size = new System.Drawing.Size(94, 57);
            this.btnPrimeiroEspaço.TabIndex = 2;
            this.btnPrimeiroEspaço.Text = "Primeiro espaço em branco";
            this.btnPrimeiroEspaço.UseVisualStyleBackColor = true;
            this.btnPrimeiroEspaço.Click += new System.EventHandler(this.btnPrimeiroEspaço_Click);
            // 
            // btnContLetras
            // 
            this.btnContLetras.Location = new System.Drawing.Point(558, 263);
            this.btnContLetras.Name = "btnContLetras";
            this.btnContLetras.Size = new System.Drawing.Size(90, 57);
            this.btnContLetras.TabIndex = 3;
            this.btnContLetras.Text = "Contar Letras";
            this.btnContLetras.UseVisualStyleBackColor = true;
            this.btnContLetras.Click += new System.EventHandler(this.btnContLetras_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnContLetras);
            this.Controls.Add(this.btnPrimeiroEspaço);
            this.Controls.Add(this.btnCont);
            this.Controls.Add(this.rchtxtFrase);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnCont;
        private System.Windows.Forms.Button btnPrimeiroEspaço;
        private System.Windows.Forms.Button btnContLetras;
    }
}