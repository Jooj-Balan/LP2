﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            string saida = "";
            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i + 1}° número", "Entrada de Dados");

                if (auxiliar == "")
                    break;

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }
                else
                {
                    saida = auxiliar + "\n" + saida;
                }
            }

            Array.Reverse(vetor); //inverter
            auxiliar = "";

            foreach (int i in vetor)
            {
                auxiliar += i + "\n";
            }

            MessageBox.Show(auxiliar);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            string auxiliar = "";

            ArrayList alunos = new ArrayList();
            alunos.Add("Ana");
            alunos.Add("André");
            alunos.Add("Débora");
            alunos.Add("Fátima");
            alunos.Add("João");
            alunos.Add("Janete");
            alunos.Add("Otávio");
            alunos.Add("Marcelo");
            alunos.Add("Pedro");
            alunos.Add("Thais");
            alunos.Remove("Otávio");

            foreach (string item in alunos)
            {
                auxiliar += item + "\n";
            }

            MessageBox.Show(auxiliar);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {


            double[,] notas = new double[20, 3];
            string auxiliar = "";
            double[] resultado = new double[20];
            double media = 0.0;
            int k = 0;
            

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a {j + 1}ª Nota do aluno {i + 1}", "Média dos alunos");

                    

                    if (!double.TryParse(auxiliar, out notas[i, j]))
                    {
                        MessageBox.Show("Digite um número de 0 a 10");
                        j--;
                    }
                    else if (Convert.ToDouble(auxiliar) < 0 || Convert.ToDouble(auxiliar) > 10)
                    {
                        MessageBox.Show("Digite um número de 0 a 10");
                        j--;
                    }
                    else
                    {
                        media = media + notas[i, j];
                    }                   
                }
                resultado[k++] = media / 3;
                media = 0;
            }

            auxiliar = "";
            for (k=0; k<20; k++)
            {
                auxiliar += $"A media do Aluno {k + 1} é: {resultado[k].ToString("N2")}" + "\n";
            }

            MessageBox.Show(auxiliar);
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["frmExercicio4"].BringToFront();
            }
            else
            {
                frmExercicio4 obj4 = new frmExercicio4();
                obj4.WindowState = FormWindowState.Normal;
                obj4.Show();
            }
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            frmExercicio5 obj5 = new frmExercicio5();
            obj5.WindowState = FormWindowState.Normal;
            obj5.Show();
        }
    }
}

                
        
    

