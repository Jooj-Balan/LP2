﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int[,] respostas = new int[5, 10];
            char[] gabarito = { 'A', 'E', 'D', 'B', 'C', 'E', 'D', 'A', 'C', 'B' };
            string auxiliar = "";
           

            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a resposta do {i + 1}º aluno da {j + 1}º questão: ",
                        "Correção");
                    
                    
                    if (auxiliar.Length > 1)
                    {
                        auxiliar = auxiliar.Substring(0,1);
                    }
                    
                    if ((Convert.ToChar(auxiliar.ToUpper()) != 'A') && (Convert.ToChar(auxiliar.ToUpper()) != 'B') &&
                        (Convert.ToChar(auxiliar.ToUpper()) != 'C') && (Convert.ToChar(auxiliar.ToUpper()) != 'D') &&
                        (Convert.ToChar(auxiliar.ToUpper()) != 'E'))
                    {
                        MessageBox.Show("Caractere inválido, digite apenas: A, B, C, D ou E.");
                        j--;
                    }
                    else if ((Convert.ToChar(auxiliar.ToUpper())) == gabarito[j])
                    {                       
                        lstBxGabarito.Items.Add($"O aluno {i + 1} acertou a {j + 1}° questão ," +
                          $" era {gabarito[j]}  escolheu {auxiliar.ToUpper()}");
                    }
                    else
                    {
                        lstBxGabarito.Items.Add($"O aluno {i + 1} errou a {j + 1}° questão, " +
                            $" era {gabarito[j]}  escolheu {auxiliar.ToUpper()}");
                    }
                    
                }

            }
        }
    }
}
