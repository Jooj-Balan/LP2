﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAluno01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            float[,] notas = new float[5, 3];
            string auxiliar = "";
            float[] resultado = new float[5];
            float media = 0;
            int k = 0;
            int l = 0;


            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Aluno {i+1} Nota do professor {j + 1}", "Média dos alunos");


                    
                    if (!float.TryParse(auxiliar, out notas[i, j]))
                    {
                        MessageBox.Show("Digite a nota do aluno");
                        j--;
                    }
                    else if (Convert.ToDouble(auxiliar) < 0 || Convert.ToDouble(auxiliar) > 10)
                    {
                        MessageBox.Show("Digite a nota do aluno");
                        j--;
                    }
                    else
                    {
                    
                    media = media + notas[i, j];
                    }
                    
                }
                resultado[k++] = media / 3;
                media = 0;
                    
            }

            auxiliar = "";
            for (k = 0; k < 5; k++)
            {
                auxiliar += $"Media dos alunos: {resultado[k].ToString("N2")}" + "\n";
            }

            MessageBox.Show(auxiliar);

            auxiliar = "";
            for (l = 0; l < 1; l++)
            {
                resultado[l++] = media / 5;
                auxiliar += $"Media Geral Alunos: {resultado[l].ToString("N2")}" + "\n";
            }

            MessageBox.Show(auxiliar);


        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxListaNome.Items.Clear();
        }
    }
}
