﻿namespace PClasses
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInsatanciarMensalista = new System.Windows.Forms.Button();
            this.btnInstanciarMensalistaPassandoParametros = new System.Windows.Forms.Button();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSalMensal = new System.Windows.Forms.TextBox();
            this.txtDataEntrada = new System.Windows.Forms.TextBox();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalarioMensal = new System.Windows.Forms.Label();
            this.lblDatadeEntrada = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnInsatanciarMensalista
            // 
            this.btnInsatanciarMensalista.Location = new System.Drawing.Point(148, 284);
            this.btnInsatanciarMensalista.Name = "btnInsatanciarMensalista";
            this.btnInsatanciarMensalista.Size = new System.Drawing.Size(113, 76);
            this.btnInsatanciarMensalista.TabIndex = 0;
            this.btnInsatanciarMensalista.Text = "Instanciar mensalista";
            this.btnInsatanciarMensalista.UseVisualStyleBackColor = true;
            // 
            // btnInstanciarMensalistaPassandoParametros
            // 
            this.btnInstanciarMensalistaPassandoParametros.Location = new System.Drawing.Point(401, 284);
            this.btnInstanciarMensalistaPassandoParametros.Name = "btnInstanciarMensalistaPassandoParametros";
            this.btnInstanciarMensalistaPassandoParametros.Size = new System.Drawing.Size(100, 76);
            this.btnInstanciarMensalistaPassandoParametros.TabIndex = 1;
            this.btnInstanciarMensalistaPassandoParametros.Text = "Instanciar mensalista passando parametros";
            this.btnInstanciarMensalistaPassandoParametros.UseVisualStyleBackColor = true;
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(401, 59);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(100, 22);
            this.txtMatricula.TabIndex = 2;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(401, 117);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 22);
            this.txtNome.TabIndex = 3;
            // 
            // txtSalMensal
            // 
            this.txtSalMensal.Location = new System.Drawing.Point(401, 172);
            this.txtSalMensal.Name = "txtSalMensal";
            this.txtSalMensal.Size = new System.Drawing.Size(100, 22);
            this.txtSalMensal.TabIndex = 4;
            // 
            // txtDataEntrada
            // 
            this.txtDataEntrada.Location = new System.Drawing.Point(401, 218);
            this.txtDataEntrada.Name = "txtDataEntrada";
            this.txtDataEntrada.Size = new System.Drawing.Size(100, 22);
            this.txtDataEntrada.TabIndex = 5;
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Location = new System.Drawing.Point(145, 59);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(61, 16);
            this.lblMatricula.TabIndex = 6;
            this.lblMatricula.Text = "Matricula";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(145, 117);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(44, 16);
            this.lblNome.TabIndex = 7;
            this.lblNome.Text = "Nome";
            // 
            // lblSalarioMensal
            // 
            this.lblSalarioMensal.AutoSize = true;
            this.lblSalarioMensal.Location = new System.Drawing.Point(145, 175);
            this.lblSalarioMensal.Name = "lblSalarioMensal";
            this.lblSalarioMensal.Size = new System.Drawing.Size(97, 16);
            this.lblSalarioMensal.TabIndex = 8;
            this.lblSalarioMensal.Text = "Salario mensal";
            // 
            // lblDatadeEntrada
            // 
            this.lblDatadeEntrada.AutoSize = true;
            this.lblDatadeEntrada.Location = new System.Drawing.Point(145, 224);
            this.lblDatadeEntrada.Name = "lblDatadeEntrada";
            this.lblDatadeEntrada.Size = new System.Drawing.Size(179, 16);
            this.lblDatadeEntrada.TabIndex = 9;
            this.lblDatadeEntrada.Text = "Data de entrada na empresa";
            // 
            // frmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblDatadeEntrada);
            this.Controls.Add(this.lblSalarioMensal);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMatricula);
            this.Controls.Add(this.txtDataEntrada);
            this.Controls.Add(this.txtSalMensal);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.btnInstanciarMensalistaPassandoParametros);
            this.Controls.Add(this.btnInsatanciarMensalista);
            this.Name = "frmMensalista";
            this.Text = "frmMensalista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnInsatanciarMensalista;
        private System.Windows.Forms.Button btnInstanciarMensalistaPassandoParametros;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSalMensal;
        private System.Windows.Forms.TextBox txtDataEntrada;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalarioMensal;
        private System.Windows.Forms.Label lblDatadeEntrada;
    }
}