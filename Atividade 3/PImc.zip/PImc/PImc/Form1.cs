﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPeso.Clear();
            mskbxAltura.Clear();
            txtImc.Clear();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            txtImc.Clear();

            if (!Double.TryParse(mskbxPeso.Text, out peso)||
                !Double.TryParse(mskbxAltura.Text, out altura))
            {
                mskbxPeso.Focus(); 
            }
            else
            {
                imc = peso / (altura * altura);
                imc = Math.Round(imc, 1);
                txtImc.Text = imc.ToString();


                if (imc < 18.5) 
                MessageBox.Show("Magreza");

                if (imc >= 18.5 && imc < 25.0)
                    MessageBox.Show("Normal");

                if (imc >= 25.0 && imc < 30.0)
                    MessageBox.Show("Sobrepeso");

                if (imc >= 30.0 && imc < 40.0)
                    MessageBox.Show("Obesidade");

                if (imc > 40.0)
                    MessageBox.Show("Obesidade Grave");
            }
        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskbxPeso.Text, out peso))
            {
                errorProvider1.SetError(mskbxPeso, "Peso Inválido");
            }
            else
                errorProvider1.SetError(mskbxPeso, "");
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo? Serio???",
                "Saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) ==
                DialogResult.Yes)
            {
                Close();
            }
        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskbxAltura.Text, out altura))
            {
                errorProvider2.SetError(mskbxAltura, "Altura Inválido");
            }
            else
                errorProvider2.SetError(mskbxAltura, "");
        }

        private void txtImc_Validated(object sender, EventArgs e)
        {

        }
    }
}
