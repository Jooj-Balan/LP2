﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado; //globais

        private void txtnumero2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(txtnumero2, "");
                numero2 = Convert.ToDouble(txtnumero2.Text);
            }
            catch (Exception) 
            {
                errorProvider2.SetError(txtnumero2, "Numero 2 inválido");
            }
        }

        private void btnsoma_Click(object sender, EventArgs e)
        {
            txtresultado.Clear();

            if (!Double.TryParse(txtnumero1.Text, out numero1)||
                !Double.TryParse(txtnumero2.Text, out numero2))
            {
                txtnumero1.Focus(); ;
            }
            else 
            {
                resultado = numero1 + numero2;
                txtresultado.Text = resultado.ToString();

            }
        }

        private void btnsub_Click(object sender, EventArgs e)
        {
            txtresultado.Clear();

            if (!Double.TryParse(txtnumero1.Text, out numero1) ||
                !Double.TryParse(txtnumero2. Text, out numero2))
            {
                txtnumero1.Focus(); ;
            }
            else
            {
                resultado = numero1 - numero2;
                txtresultado.Text = resultado.ToString();

            }
        }

        private void btnmply_Click(object sender, EventArgs e)
        {
            txtresultado.Clear();

            if (!Double.TryParse(txtnumero1.Text, out numero1) ||
                !Double.TryParse(txtnumero2. Text, out numero2))
            {
                txtnumero1.Focus(); ;
            }
            else
            {
                resultado = numero1 * numero2;
                txtresultado.Text = resultado.ToString();

            }
        }

        private void btndiv_Click(object sender, EventArgs e)
        {
            txtresultado.Clear();

            if (!Double.TryParse(txtnumero1.Text, out numero1) ||
                !Double.TryParse(txtnumero2. Text, out numero2))
            {
                txtnumero1.Focus(); 
            }
            else
            {
                if (numero2 == 0)
                {
                    errorProvider2.SetError(txtnumero2, "NUmero 2 inválido");
                    txtnumero2.Focus();
                }
                else
                {
                    resultado = numero1 / numero2;
                    txtresultado.Text = resultado.ToString();
                }

            }
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtnumero1.Clear();
            txtnumero2.Clear();
            txtresultado.Clear();
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo? Serio???",
                "Saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) ==
                DialogResult.Yes)
            {
                Close();
            }
        }


        public Form1()
        {
            InitializeComponent();
        }

        private void txtnumero1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtnumero1.Text, out numero1))
            {
                //MessageBox.Show("número inválido");
                errorProvider1.SetError(txtnumero1, "Numero 1 Inválido");
                //txtnumero1.Focus();
            }
            else
                errorProvider1.SetError(txtnumero1, "");
        }
    }
}
